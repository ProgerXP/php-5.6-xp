<?php
echo "Testing gd: ";
if (isFunctionOK("gd_info") && isFunctionOK("getimagesize") && isFunctionOK("getimagesizefromstring"))
{
	gd_info();
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>