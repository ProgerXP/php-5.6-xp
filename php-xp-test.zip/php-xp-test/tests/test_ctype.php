<?php
echo "Testing ctype: ";
if (isFunctionOK("ctype_alnum") && isFunctionOK("ctype_alpha") && isFunctionOK("ctype_cntrl"))
{
	$number = ctype_alnum('AbCd1zyZ9');
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>