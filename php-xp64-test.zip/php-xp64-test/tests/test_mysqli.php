<?php
echo "Testing mysqli: ";
if (isFunctionOK("mysqli_get_client_info ") && isFunctionOK("mysqli_error") && isFunctionOK("mysqli_init"))
{
	mysqli_get_client_info();
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>