<?php
echo "Testing fileinfo: ";
if (isFunctionOK("finfo_buffer") && isFunctionOK("finfo_close") && isFunctionOK("finfo_file") && isFunctionOK("finfo_open"))
{
	$finfo = new finfo(FILEINFO_MIME);
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>