<?php
echo "Testing mcrypt: ";
if (isFunctionOK("mcrypt_cbc") && isFunctionOK("mcrypt_cfb") && isFunctionOK("mcrypt_module_open"))
{
	$td = mcrypt_module_open('des', '', 'ecb', '');
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>