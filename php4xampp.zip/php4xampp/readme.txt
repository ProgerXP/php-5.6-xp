Setup Windows XP to use PHP 5.6.24 in XAMPP Server:

1. Install MSVC++2012 redistributable (x86) from vcredist_x86.exe
2. Copy php folder contents to XAMPP Server (C:\xampp\php), overwrite existing files

PS: Please note the only extensions which uses separate dll files are [Curl] and [Fileinfo].
Thus, you need to comment useless lines in your php.ini (extension=..)