<?php
include "helper.php";
include "test_calendar.php";
include "test_ctype.php";
include "test_curl.php";
include "test_date.php";
include "test_finfo.php";
include "test_filter.php";
include "test_gd.php";
include "test_hash.php";
include "test_iconv.php";
include "test_json.php";
include "test_mbstring.php";
include "test_mcrypt.php";
include "test_mysqli.php";
include "test_openssl.php";
include "test_pcre.php";
include "test_pdo.php";
include "test_session.php";
include "test_spl.php";
include "test_zlib.php";
?>