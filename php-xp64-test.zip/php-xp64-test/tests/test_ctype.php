<?php
echo "Testing ctype: ";
if (isFunctionOK("ctype_alnum") && isFunctionOK("ctype_alpha") && isFunctionOK("ctype_cntrl"))
{
	$number = ctype_alnum('AbCd1zyZ9');
	echo "OK\r\n";
}
else
{
	echo "FAILED\r\n";
}
?>