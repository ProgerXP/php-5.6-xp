<?php
echo "Testing hash: ";
if (isFunctionOK("hash") && isFunctionOK("hash_copy") && isFunctionOK("hash_file"))
{
	hash('ripemd160', 'The quick brown fox jumped over the lazy dog.');
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>