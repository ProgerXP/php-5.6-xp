<?php
echo "Testing iconv: ";
if (isFunctionOK("iconv") && isFunctionOK("iconv_get_encoding") && isFunctionOK("iconv_substr"))
{
	$text = "Test text string.";
	iconv("UTF-8", "ISO-8859-1//TRANSLIT", $text);
	echo "OK" . PHP_EOL;
}
else
{
	echo "FAILED" . PHP_EOL;
}
?>